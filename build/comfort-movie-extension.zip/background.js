"use strict";
const defaultMenuSettings = {
    showContextMenu: true,
    showVideoContextMenu: true
};
async function createContextMenus() {
    try {
        await chrome.contextMenus.removeAll();
        const result = await chrome.storage.sync.get(defaultMenuSettings);
        const settings = result;
        if (settings.showContextMenu) {
            chrome.contextMenus.create({
                id: 'comfort-mode-toggle',
                title: chrome.i18n.getMessage('contextMenuToggle'),
                contexts: ['all']
            });
        }
        if (settings.showVideoContextMenu) {
            chrome.contextMenus.create({
                id: 'comfort-mode-video-toggle',
                title: chrome.i18n.getMessage('contextMenuVideoToggle'),
                contexts: ['video']
            });
        }
    }
    catch (error) {
        console.error('コンテキストメニューの作成に失敗しました:', error);
    }
}
chrome.runtime.onInstalled.addListener(() => {
    createContextMenus();
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if ((info.menuItemId === 'comfort-mode-toggle' || info.menuItemId === 'comfort-mode-video-toggle') && tab?.id) {
        const message = {
            action: 'toggleComfortMode',
            isVideoContext: info.menuItemId === 'comfort-mode-video-toggle',
            clickedElementInfo: info.menuItemId === 'comfort-mode-video-toggle' ? {
                srcUrl: info.srcUrl,
                pageUrl: info.pageUrl
            } : undefined
        };
        chrome.tabs.sendMessage(tab.id, message, (response) => {
            if (chrome.runtime.lastError) {
                console.error('コンテンツスクリプトとの通信に失敗しました:', chrome.runtime.lastError);
            }
            else if (response?.success) {
                const context = info.menuItemId === 'comfort-mode-video-toggle' ? '(動画から)' : '';
                console.log(`快適モードが切り替えられました ${context}`);
            }
        });
    }
});
chrome.action.onClicked.addListener((tab) => {
    if (tab.id) {
        chrome.tabs.sendMessage(tab.id, { action: 'toggleComfortMode' }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('コンテンツスクリプトとの通信に失敗しました:', chrome.runtime.lastError);
            }
            else if (response?.success) {
                console.log('快適モードが切り替えられました');
            }
        });
    }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'updateContextMenus') {
        createContextMenus();
        sendResponse({ success: true });
    }
});
