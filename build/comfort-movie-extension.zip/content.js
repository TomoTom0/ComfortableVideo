"use strict";
let isComfortModeActive = false;
let originalVideoStyles = new Map();
let exitButton = null;
let zIndexStyle = null;
let cursorTimer = null;
let controlsDisableTimer = null;
let isVideoControlsEnabled = false;
let lastIsInVideoArea = false;
const HOVER_DETECTION_TIME = 2000;
const CONTROLS_DISABLE_TIME = 3000;
function enableComfortMode() {
    const videos = document.querySelectorAll('video');
    if (videos.length === 0) {
        alert('動画が見つかりません');
        return;
    }
    isComfortModeActive = true;
    videos.forEach(video => {
        if (video.videoWidth > 0 && video.videoHeight > 0) {
            const computedStyle = window.getComputedStyle(video);
            originalVideoStyles.set(video, {
                position: computedStyle.position,
                top: computedStyle.top,
                left: computedStyle.left,
                width: computedStyle.width,
                height: computedStyle.height,
                zIndex: computedStyle.zIndex,
                transform: computedStyle.transform
            });
            maximizeVideo(video);
            video.classList.add('comfort-mode-video');
            let parent = video.parentElement;
            if (parent) {
                parent.classList.add('comfort-mode-video-container');
            }
        }
    });
    applyZIndexControl();
    disableMouseEvents();
    startCursorDetection();
    showExitButton();
}
function maximizeVideo(video) {
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;
    const videoAspectRatio = video.videoWidth / video.videoHeight;
    const windowAspectRatio = windowWidth / windowHeight;
    let newWidth;
    let newHeight;
    let offsetX = 0;
    let offsetY = 0;
    if (videoAspectRatio > windowAspectRatio) {
        newWidth = windowWidth;
        newHeight = windowWidth / videoAspectRatio;
        offsetY = (windowHeight - newHeight) / 2;
    }
    else {
        newHeight = windowHeight;
        newWidth = windowHeight * videoAspectRatio;
        offsetX = (windowWidth - newWidth) / 2;
    }
    video.style.cssText += `
    position: fixed !important;
    top: ${offsetY}px !important;
    left: ${offsetX}px !important;
    width: ${newWidth}px !important;
    height: ${newHeight}px !important;
    object-fit: fill !important;
    transform: none !important;
  `;
}
function disableMouseEvents() {
    const style = document.createElement('style');
    style.id = 'comfort-mode-style';
    style.textContent = `
    /* コントロール無効時のみpointer-eventsを無効化 */
    body.comfort-mode-active:not(.video-controls-enabled) * {
      pointer-events: none !important;
    }
    body.comfort-mode-active #comfort-mode-exit-button {
      pointer-events: auto !important;
    }
  `;
    document.head.appendChild(style);
}
function applyZIndexControl() {
    zIndexStyle = document.createElement('style');
    zIndexStyle.id = 'comfort-mode-zindex-control';
    zIndexStyle.textContent = `
    /* 動画を最前面に */
    .comfort-mode-video {
      z-index: 2147483647 !important;
    }

    /* 他の要素のz-indexを制限 */
    body.comfort-mode-active *:not(.comfort-mode-video):not(#comfort-mode-exit-button) {
      z-index: 999998 !important;
    }

    /* 解除ボタンを動画より上に */
    #comfort-mode-exit-button {
      z-index: 2147483648 !important;
    }
  `;
    document.head.appendChild(zIndexStyle);
    document.body.classList.add('comfort-mode-active');
}
function removeZIndexControl() {
    if (zIndexStyle) {
        zIndexStyle.remove();
        zIndexStyle = null;
    }
    document.body.classList.remove('comfort-mode-active');
    document.body.classList.remove('video-area-hovered');
    const videos = document.querySelectorAll('video.comfort-mode-video');
    videos.forEach(video => {
        video.classList.remove('comfort-mode-video');
        const parent = video.parentElement;
        if (parent) {
            parent.classList.remove('comfort-mode-video-container');
        }
    });
}
function startCursorDetection() {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('click', handleClick);
}
function stopCursorDetection() {
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('click', handleClick);
    if (cursorTimer) {
        clearTimeout(cursorTimer);
        cursorTimer = null;
    }
    if (controlsDisableTimer) {
        clearTimeout(controlsDisableTimer);
        controlsDisableTimer = null;
    }
    disableVideoControls();
}
function handleMouseMove(event) {
    if (!isComfortModeActive)
        return;
    window.lastMouseEvent = event;
    const videos = document.querySelectorAll('video.comfort-mode-video');
    if (videos.length === 0)
        return;
    let isInVideoArea = false;
    let isInVideoBottomArea = false;
    videos.forEach(video => {
        const rect = video.getBoundingClientRect();
        if (event.clientX >= rect.left && event.clientX <= rect.right &&
            event.clientY >= rect.top && event.clientY <= rect.bottom) {
            isInVideoArea = true;
            const bottomAreaHeight = rect.height * 0.2;
            const bottomAreaTop = rect.bottom - bottomAreaHeight;
            if (event.clientY >= bottomAreaTop) {
                isInVideoBottomArea = true;
            }
        }
    });
    if (isInVideoArea !== lastIsInVideoArea) {
        updateExitButtonOpacity(isInVideoArea);
        lastIsInVideoArea = isInVideoArea;
        if (isInVideoArea) {
            document.body.classList.add('video-area-hovered');
        }
        else {
            document.body.classList.remove('video-area-hovered');
        }
    }
    if (isInVideoArea) {
        if (controlsDisableTimer) {
            clearTimeout(controlsDisableTimer);
            controlsDisableTimer = null;
        }
    }
    else {
        if (isVideoControlsEnabled && !controlsDisableTimer) {
            controlsDisableTimer = setTimeout(() => {
                disableVideoControls();
                controlsDisableTimer = null;
            }, CONTROLS_DISABLE_TIME);
        }
    }
    if (isInVideoBottomArea) {
        if (!isVideoControlsEnabled) {
            if (cursorTimer) {
                clearTimeout(cursorTimer);
            }
            cursorTimer = setTimeout(() => {
                enableVideoControls();
                cursorTimer = null;
            }, HOVER_DETECTION_TIME);
        }
    }
    else {
        if (cursorTimer) {
            clearTimeout(cursorTimer);
            cursorTimer = null;
        }
    }
}
function handleClick(event) {
    if (!isComfortModeActive)
        return;
    const videos = document.querySelectorAll('video.comfort-mode-video');
    if (videos.length === 0)
        return;
    let isClickInVideoBottomArea = false;
    videos.forEach(video => {
        const rect = video.getBoundingClientRect();
        const isInVideoArea = event.clientX >= rect.left && event.clientX <= rect.right &&
            event.clientY >= rect.top && event.clientY <= rect.bottom;
        if (isInVideoArea) {
            const bottomAreaHeight = rect.height * 0.2;
            const bottomAreaTop = rect.bottom - bottomAreaHeight;
            if (event.clientY >= bottomAreaTop) {
                isClickInVideoBottomArea = true;
            }
        }
    });
    if (isClickInVideoBottomArea) {
        if (cursorTimer) {
            clearTimeout(cursorTimer);
            cursorTimer = null;
        }
        if (!isVideoControlsEnabled) {
            enableVideoControls();
        }
    }
}
function enableVideoControls() {
    if (!isVideoControlsEnabled) {
        isVideoControlsEnabled = true;
        document.body.classList.add('video-controls-enabled');
        const videos = document.querySelectorAll('video.comfort-mode-video');
        let isInVideoArea = false;
        const lastMouseEvent = window.lastMouseEvent;
        if (lastMouseEvent && videos.length > 0) {
            videos.forEach(video => {
                const rect = video.getBoundingClientRect();
                if (lastMouseEvent.clientX >= rect.left && lastMouseEvent.clientX <= rect.right &&
                    lastMouseEvent.clientY >= rect.top && lastMouseEvent.clientY <= rect.bottom) {
                    isInVideoArea = true;
                }
            });
        }
        updateExitButtonOpacity(isInVideoArea);
    }
}
function disableVideoControls() {
    if (isVideoControlsEnabled) {
        isVideoControlsEnabled = false;
        document.body.classList.remove('video-controls-enabled');
        const videos = document.querySelectorAll('video.comfort-mode-video');
        let isInVideoArea = false;
        const lastMouseEvent = window.lastMouseEvent;
        if (lastMouseEvent && videos.length > 0) {
            videos.forEach(video => {
                const rect = video.getBoundingClientRect();
                if (lastMouseEvent.clientX >= rect.left && lastMouseEvent.clientX <= rect.right &&
                    lastMouseEvent.clientY >= rect.top && lastMouseEvent.clientY <= rect.bottom) {
                    isInVideoArea = true;
                }
            });
        }
        updateExitButtonOpacity(isInVideoArea);
    }
}
function updateExitButtonOpacity(isInVideoArea) {
    if (!exitButton)
        return;
    if (isVideoControlsEnabled) {
        exitButton.style.background = 'rgba(255, 255, 255, 0.15) !important';
        exitButton.style.color = 'rgba(255, 255, 255, 0.6) !important';
        exitButton.style.borderColor = 'rgba(255, 255, 255, 0.15) !important';
    }
    else if (isInVideoArea) {
        exitButton.style.background = 'rgba(255, 255, 255, 0.1) !important';
        exitButton.style.color = 'rgba(255, 255, 255, 0.4) !important';
        exitButton.style.borderColor = 'rgba(255, 255, 255, 0.1) !important';
    }
    else {
        exitButton.style.background = 'transparent !important';
        exitButton.style.color = 'rgba(255, 255, 255, 0.2) !important';
        exitButton.style.borderColor = 'transparent !important';
    }
}
function showExitButton() {
    exitButton = document.createElement('div');
    exitButton.id = 'comfort-mode-exit-button';
    exitButton.innerHTML = '×';
    exitButton.title = '快適モード解除';
    exitButton.style.cssText = `
    position: fixed !important;
    bottom: 15px !important;
    right: 15px !important;
    background: transparent !important;
    color: rgba(255, 255, 255, 0.2) !important;
    width: 28px !important;
    height: 28px !important;
    border-radius: 50% !important;
    cursor: pointer !important;
    z-index: 2147483648 !important;
    font-family: Arial, sans-serif !important;
    font-size: 18px !important;
    font-weight: bold !important;
    user-select: none !important;
    pointer-events: auto !important;
    border: 1px solid transparent !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    transition: all 0.2s ease !important;
  `;
    exitButton.addEventListener('click', disableComfortMode);
    exitButton.addEventListener('mouseenter', () => {
        if (exitButton && isVideoControlsEnabled) {
            exitButton.style.background = 'rgba(255, 255, 255, 0.25) !important';
            exitButton.style.color = 'rgba(255, 255, 255, 0.9) !important';
            exitButton.style.borderColor = 'rgba(255, 255, 255, 0.4) !important';
        }
    });
    exitButton.addEventListener('mouseleave', () => {
        if (exitButton && isVideoControlsEnabled) {
            const videos = document.querySelectorAll('video.comfort-mode-video');
            let isInVideoArea = false;
            const lastMouseEvent = window.lastMouseEvent;
            if (lastMouseEvent && videos.length > 0) {
                videos.forEach(video => {
                    const rect = video.getBoundingClientRect();
                    if (lastMouseEvent.clientX >= rect.left && lastMouseEvent.clientX <= rect.right &&
                        lastMouseEvent.clientY >= rect.top && lastMouseEvent.clientY <= rect.bottom) {
                        isInVideoArea = true;
                    }
                });
            }
            setTimeout(() => {
                updateExitButtonOpacity(isInVideoArea);
            }, 10);
        }
    });
    document.body.appendChild(exitButton);
}
function disableComfortMode() {
    if (!isComfortModeActive)
        return;
    isComfortModeActive = false;
    originalVideoStyles.forEach((originalStyle, video) => {
        video.style.position = originalStyle.position;
        video.style.top = originalStyle.top;
        video.style.left = originalStyle.left;
        video.style.width = originalStyle.width;
        video.style.height = originalStyle.height;
        video.style.zIndex = originalStyle.zIndex;
        video.style.transform = originalStyle.transform;
        video.style.objectFit = '';
    });
    originalVideoStyles.clear();
    stopCursorDetection();
    removeZIndexControl();
    const style = document.getElementById('comfort-mode-style');
    if (style) {
        style.remove();
    }
    if (exitButton) {
        exitButton.remove();
        exitButton = null;
    }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'toggleComfortMode') {
        if (isComfortModeActive) {
            disableComfortMode();
        }
        else {
            enableComfortMode();
        }
        sendResponse({ success: true });
    }
});
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && isComfortModeActive) {
        disableComfortMode();
    }
});
window.addEventListener('resize', () => {
    if (isComfortModeActive) {
        const videos = document.querySelectorAll('video');
        videos.forEach(video => {
            if (video.videoWidth > 0 && video.videoHeight > 0) {
                maximizeVideo(video);
            }
        });
    }
});
